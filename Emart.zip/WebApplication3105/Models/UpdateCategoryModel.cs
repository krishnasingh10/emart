﻿namespace WebApplication3105.Models
{
    public class UpdateCategoryModel
    {

        public int CategoryId { get; set; }

        public String CategoryName { get; set; }
    }
}
