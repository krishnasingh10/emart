﻿namespace WebApplication3105.Models
{
    public class ProductCategory
    {

       public Product product { get; set; } 

        public Category category { get; set; }  
    }
}
